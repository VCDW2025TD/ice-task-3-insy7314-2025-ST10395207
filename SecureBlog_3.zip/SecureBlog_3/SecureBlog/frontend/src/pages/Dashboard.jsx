export default function Dashboard() {
    return <h2>Welcome to your dashboard!</h2>;
  }
  